package com.Site.back.Repository;

public interface ParentsRepository {

}
